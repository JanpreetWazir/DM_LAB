#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <iomanip>
#include <vector>

using namespace std;

double calculateProbability(int count, int total) {
    return (total == 0) ? 0.0 : static_cast<double>(count) / total;
}

int main() {
    // Open the CSV file
    fstream file("ass4_cricket_data.csv", ios::in);
    if (!file.is_open()) {
        cout << "Error in opening the file." << endl;
        return 1;
    }

    string line;
    // Skip the header line
    getline(file, line);

    // Map to store the counts of "Yes" and "No" for each attribute-value pair
    map<string, map<string, pair<int, int>>> attributeMap;

    int total = 0, yesCount = 0, noCount = 0;

    // Read each line of the CSV file
    while (getline(file, line)) {
        stringstream ss(line);

        string outlook, temperature, humidity, wind, playing;
        
        // Read each field of the line
        getline(ss, outlook, ',');
        getline(ss, temperature, ',');
        getline(ss, humidity, ',');
        getline(ss, wind, ',');
        getline(ss, playing, ',');

        // Update the map for each attribute-value pair
        if (playing == "Yes") {
            attributeMap["Outlook"][outlook].first++;       // Increment "Yes" count for Outlook
            attributeMap["Temperature"][temperature].first++; // Increment "Yes" count for Temperature
            attributeMap["Humidity"][humidity].first++;     // Increment "Yes" count for Humidity
            attributeMap["Wind"][wind].first++;             // Increment "Yes" count for Wind
            yesCount++;
        } else {
            attributeMap["Outlook"][outlook].second++;      // Increment "No" count for Outlook
            attributeMap["Temperature"][temperature].second++; // Increment "No" count for Temperature
            attributeMap["Humidity"][humidity].second++;    // Increment "No" count for Humidity
            attributeMap["Wind"][wind].second++;            // Increment "No" count for Wind
            noCount++;
        }

        total++;
    }

    file.close();

    // Calculate prior probabilities
    double pYes = calculateProbability(yesCount, total);
    double pNo = calculateProbability(noCount, total);

    // Display prior probabilities
    cout << fixed << setprecision(4);
    cout << "Prior Probabilities:" << endl;
    cout << "P(Yes) = " << pYes << endl;
    cout << "P(No) = " << pNo << endl;

    // Input for the new case
    string outlook, temperature, humidity, wind;
    cout << "\nEnter the weather conditions for a new case:" << endl;
    cout << "Outlook (Sunny, Overcast, Rain): ";
    getline(cin, outlook);
    cout << "Temperature (Hot, Mild, Cool): ";
    getline(cin, temperature);
    cout << "Humidity (High, Normal): ";
    getline(cin, humidity);
    cout << "Wind (Weak, Strong): ";
    getline(cin, wind);

    vector<string> newCase = {outlook, temperature, humidity, wind};
    vector<string> attributes = {"Outlook", "Temperature", "Humidity", "Wind"};

    // Manually calculate the likelihood for "Yes" with intermediate probabilities
    double yesLikelihood = 1.0;
    cout << "\nLikelihoods for P(Yes):" << endl;
    for (size_t i = 0; i < newCase.size(); ++i) {
        const string& attributeValue = newCase[i];
        const string& attribute = attributes[i];

        // Get the counts for the attribute value and class ("Yes")
        int yesCountForAttribute = attributeMap[attribute][attributeValue].first;
        int totalYes = yesCount;

        // Calculate and print the likelihood for the attribute value given "Yes"
        double likelihoodYes = calculateProbability(yesCountForAttribute, totalYes);
        cout << "P(" << attributeValue << " | Yes) = " << likelihoodYes << endl;

        // Multiply the likelihoods for each attribute
        yesLikelihood *= likelihoodYes;
    }

    // Manually calculate the likelihood for "No" with intermediate probabilities
    double noLikelihood = 1.0;
    cout << "\nLikelihoods for P(No):" << endl;
    for (size_t i = 0; i < newCase.size(); ++i) {
        const string& attributeValue = newCase[i];
        const string& attribute = attributes[i];

        // Get the counts for the attribute value and class ("No")
        int noCountForAttribute = attributeMap[attribute][attributeValue].second;
        int totalNo = noCount;

        // Calculate and print the likelihood for the attribute value given "No"
        double likelihoodNo = calculateProbability(noCountForAttribute, totalNo);
        cout << "P(" << attributeValue << " | No) = " << likelihoodNo << endl;

        // Multiply the likelihoods for each attribute
        noLikelihood *= likelihoodNo;
    }

    // Calculate posterior probabilities
    double yesPosterior = pYes * yesLikelihood;
    double noPosterior = pNo * noLikelihood;

    // Display posterior probabilities
    cout << "\nPosterior Probabilities:" << endl;
    cout << "P(Yes | New Case) = " << yesPosterior << endl;
    cout << "P(No | New Case) = " << noPosterior << endl;

    // Classify the new case
    if (yesPosterior > noPosterior) {
        cout << "\nClassified as: Yes (Cricket will be played)" << endl;
    } else {
        cout << "\nClassified as: No (Cricket will not be played)" << endl;
    }

    return 0;
}