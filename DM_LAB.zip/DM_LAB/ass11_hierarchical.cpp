// #include <iostream>
// #include <fstream>
// #include <vector>
// #include <cmath>
// #include <limits>

// using namespace std;

// double singleLinkage(const vector<double>& c1, const vector<double>& c2);
// double completeLinkage(const vector<double>& c1, const vector<double>& c2);
// double averageLinkage(const vector<double>& c1, const vector<double>& c2);

// int main() {
//     string file = "ass11_data.csv";
//     vector<double> weights;
//     int choice;

//     cout << "Choose Linkage Method:" << endl;
//     cout << "1. Single Linkage" << endl;
//     cout << "2. Complete Linkage" << endl;
//     cout << "3. Average Linkage" << endl;
//     cin >> choice;

    
//     fstream infile(file);
//     if (!infile.is_open()) {
//         cerr << "Unable to open file" << endl;
//         return 1;
//     }
    
//     string line;
//     getline(infile, line); 
//     while (getline(infile, line)) {
//         string::size_type sz;
//         weights.push_back(stod(line, &sz));
//     }
//     infile.close();

    
//     vector<vector<double>> clusters;
//     for (double v : weights) {
//         clusters.push_back({v});
//     }

   
//     while (clusters.size() > 1) {
//         double minDist = numeric_limits<double>::max();
//         int idx1 = -1, idx2 = -1;

//         for (size_t i = 0; i < clusters.size(); ++i) {
//             for (size_t j = i + 1; j < clusters.size(); ++j) {
//                 double dist = 0;

//                 switch (choice) {
//                     case 1:
//                         dist = singleLinkage(clusters[i], clusters[j]);
//                         break;
//                     case 2:
//                         dist = completeLinkage(clusters[i], clusters[j]);
//                         break;
//                     case 3:
//                         dist = averageLinkage(clusters[i], clusters[j]);
//                         break;
//                     default:
//                         cout << "Invalid choice. Exiting." << endl;
//                         return 1;
//                 }

//                 if (dist < minDist) {
//                     minDist = dist;
//                     idx1 = i;
//                     idx2 = j;
//                 }
//             }
//         }

//         cout << "Merging clusters with minimum distance: " << minDist << endl;
//         clusters[idx1].insert(clusters[idx1].end(), clusters[idx2].begin(), clusters[idx2].end());
//         clusters.erase(clusters.begin() + idx2);

        
//         cout << "Merged clusters: " << endl;
//         for (const auto& cluster : clusters) {
//             for (double v : cluster) {
//                 cout << v << " ";
//             }
//             cout << endl;
//         }
//     }


//     cout << "Final Cluster: " << endl;
//     for (double v : clusters[0]) {
//         cout << v << " ";
//     }
//     cout << endl;

//     return 0;
// }

// double singleLinkage(const vector<double>& c1, const vector<double>& c2) {
//     double minDist = numeric_limits<double>::max();
//     for (double v1 : c1) {
//         for (double v2 : c2) {
//             double dist = fabs(v1 - v2);
//             if (dist < minDist) {
//                 minDist = dist;
//             }
//         }
//     }
//     return minDist;
// }

// double completeLinkage(const vector<double>& c1, const vector<double>& c2) {
//     double maxDist = numeric_limits<double>::min();
//     for (double v1 : c1) {
//         for (double v2 : c2) {
//             double dist = fabs(v1 - v2);
//             if (dist > maxDist) {
//                 maxDist = dist;
//             }
//         }
//     }
//     return maxDist;
// }

// double averageLinkage(const vector<double>& c1, const vector<double>& c2) {
//     double totalDist = 0.0;
//     int count = 0;
//     for (double v1 : c1) {
//         for (double v2 : c2) {
//             totalDist += fabs(v1 - v2);
//             count++;
//         }
//     }
//     return totalDist / count;
// }




#include <iostream>
#include <vector>
#include <cmath>
#include <limits>

using namespace std;

// Function to calculate the distance between clusters using single linkage
double singleLinkage(const vector<vector<double>>& distanceMatrix, const vector<int>& cluster1, const vector<int>& cluster2);

// Function to calculate the distance between clusters using complete linkage
double completeLinkage(const vector<vector<double>>& distanceMatrix, const vector<int>& cluster1, const vector<int>& cluster2);

int main() {
    vector<vector<double>> distanceMatrix = {
        {0.0, 2.0, 3.0, 4.0},
        {2.0, 0.0, 1.0, 5.0},
        {3.0, 1.0, 0.0, 6.0},
        {4.0, 5.0, 6.0, 0.0}
    };

    int n = distanceMatrix.size();
    vector<vector<int>> clusters(n);
    for (int i = 0; i < n; ++i) {
        clusters[i] = {i};  // Initially, each element is in its own cluster
    }

    // Perform hierarchical clustering
    while (clusters.size() > 1) {
        double minDist = numeric_limits<double>::max();
        int idx1 = -1, idx2 = -1;

        // Find the minimum distance between two clusters (Single Linkage)
        for (int i = 0; i < clusters.size(); ++i) {
            for (int j = i + 1; j < clusters.size(); ++j) {
                double dist = singleLinkage(distanceMatrix, clusters[i], clusters[j]);
                if (dist < minDist) {
                    minDist = dist;
                    idx1 = i;
                    idx2 = j;
                }
            }
        }

        // Merge the two closest clusters
        cout << "Merging clusters " << idx1 << " and " << idx2 << " with distance " << minDist << endl;
        clusters[idx1].insert(clusters[idx1].end(), clusters[idx2].begin(), clusters[idx2].end());
        clusters.erase(clusters.begin() + idx2);  // Remove the second cluster

        // Print the contents of all clusters after the merge
        cout << "Clusters after merge: " << endl;
        for (int i = 0; i < clusters.size(); ++i) {
            cout << "Cluster " << i << ": ";
            for (int idx : clusters[i]) {
                cout << idx << " ";
            }
            cout << endl;
        }
    }

    // Final cluster
    cout << "Final Cluster: ";
    for (int idx : clusters[0]) {
        cout << idx << " ";
    }
    cout << endl;

    return 0;
}

double singleLinkage(const vector<vector<double>>& distanceMatrix, const vector<int>& cluster1, const vector<int>& cluster2) {
    double minDist = numeric_limits<double>::max();
    for (int i : cluster1) {
        for (int j : cluster2) {
            double dist = distanceMatrix[i][j];
            if (dist < minDist) {
                minDist = dist;
            }
        }
    }
    return minDist;
}

// Complete linkage: Maximum distance between any two points in the clusters
double completeLinkage(const vector<vector<double>>& distanceMatrix, const vector<int>& cluster1, const vector<int>& cluster2) {
    double maxDist = numeric_limits<double>::min();
    for (int i : cluster1) {
        for (int j : cluster2) {
            double dist = distanceMatrix[i][j];
            if (dist > maxDist) {
                maxDist = dist;
            }
        }
    }
    return maxDist;
}
