#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iomanip>

using namespace std;

int main() {
    string csvFile = "ass14_work.csv"; 
    string line;
    string cvsSplitBy = ",";
    
    int n = 0;
    double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

    ifstream file(csvFile);

    if (!file.is_open()) {
        cerr << "Error opening file!" << endl;
        return 1;
    }

    
    getline(file, line);

    while (getline(file, line)) {
        istringstream iss(line);
        string xStr, yStr;

        if (getline(iss, xStr, ',') && getline(iss, yStr, ',')) {
            double x = stod(xStr);
            double y = stod(yStr);

            n++;
            sumX += x;
            sumY += y;
            sumXY += (x * y);
            sumX2 += (x * x);
        }
    }
    file.close();

    double m = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    double c = (sumY - m * sumX) / n;

    cout << fixed << setprecision(4);
    cout << "Slope (m): " << m << endl;
    cout << "Intercept (c): " << c << endl;
    cout << "Linear Regression Equation: y = " << m << "x + " << c << endl;

    return 0;
}
