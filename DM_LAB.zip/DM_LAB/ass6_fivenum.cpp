#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <ostream>
using namespace std;

int quartile(int q, vector<int> &weights)
{
    int n = weights.size();
        float pos = (q / 100.0) * (n - 1); 
    int lower_idx = floor(pos);
    int upper_idx = ceil(pos);
    float quartile_value;

    if (lower_idx == upper_idx) {
        quartile_value = weights[lower_idx];
    } else {
       
        quartile_value = weights[lower_idx] + (pos - lower_idx) * (weights[upper_idx] - weights[lower_idx]);
    }   

    return quartile_value;
}

int main()
{
    fstream fr("ass6_fivenum.csv", ios::in);
    if (!fr.is_open())
    {
        cerr << "Error in opening file" << endl;  
        return 0;
    }

    string line, weight;
    vector<int> weights;
    int i = 0;
    while (getline(fr, line))
    {
        if (i == 0) 
        {
            i++;
            continue;
        }

        stringstream str(line);
        getline(str, weight, ',');

        try {
            int mk = stoi(weight);  
            weights.push_back(mk);
        }
        catch (const invalid_argument&) {
            cerr << "Invalid data encountered in the file. Skipping line." << endl;
            continue;
        }
    }

    if (weights.empty()) {
        cerr << "No data available for processing." << endl;
        return 0;
    }

    sort(weights.begin(), weights.end());
    int n = weights.size();

  
    int min_weight = weights[0], max_weight = weights[n - 1];
    float median;

    
    if (n % 2 == 1)
    {
        median = weights[(n - 1) / 2];
    }
    else
    {
        median = (weights[n / 2 - 1] + weights[n / 2]) / 2.0;
    }

    

    cout<< "Minimum Value : " << min_weight << endl;
    cout<< "Lower Quartile (Q1): " << quartile(25, weights) << endl;
    cout<< "Median : " << median << endl;
    cout<< "Upper Quartile (Q3): " << quartile(75, weights) << endl;
    cout<< "Maximum Value : " << max_weight << endl;

    
    fr.close();

    return 0;
}