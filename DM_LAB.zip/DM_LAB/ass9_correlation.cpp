#include <bits/stdc++.h>
#include <fstream>

using namespace std;

// Function to read data from CSV file and store values in two separate vectors
void readCSV(const string& fileName, vector<int>& mathScores, vector<int>& scienceScores) {
    fstream file(fileName, ios::in);
    string line;

    // Skip the header row
    getline(file, line); // Read and discard the header line

    // Read each subsequent line of the CSV
    while (getline(file, line)) {
        stringstream ss(line);
        string value;

        // Read Math and Science values (assumes Math is in the first column and Science is in the second)
        try {
            getline(ss, value, ','); // Read Math
            mathScores.push_back(stoi(value)); // Convert to integer and add to mathScores
            getline(ss, value, ','); // Read Science
            scienceScores.push_back(stoi(value)); // Convert to integer and add to scienceScores
        }
        catch (const invalid_argument& e) {
            cerr << "Error: Invalid data at line: " << line << endl;
        }
    }
}

// Function to calculate Pearson Correlation Coefficient
double findPearsonCorrelation(const vector<int>& attribute1, const vector<int>& attribute2) {
    int n = attribute1.size();
    int sumX = accumulate(attribute1.begin(), attribute1.end(), 0);
    int sumY = accumulate(attribute2.begin(), attribute2.end(), 0);
    int sumX2 = accumulate(attribute1.begin(), attribute1.end(), 0, [](int acc, int val) { return acc + val * val; });
    int sumY2 = accumulate(attribute2.begin(), attribute2.end(), 0, [](int acc, int val) { return acc + val * val; });
    int sumXY = 0;

    for (size_t i = 0; i < n; i++) {
        sumXY += attribute1[i] * attribute2[i];
    }

    double numerator = n * sumXY - sumX * sumY;
    double denominator = sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));

    return (denominator == 0) ? 0 : numerator / denominator;
}

int main() {
    // Input and output file names
    string inputFile = "ass9_student_data.csv";
    string outputFile = "PearsonCorrelation_output.csv";

    // Vectors to store Math and Science scores
    vector<int> mathScores, scienceScores;

    // Read data from CSV and store in the vectors
    readCSV(inputFile, mathScores, scienceScores);

    // Calculate Pearson Correlation Coefficient
    if (mathScores.size() > 1 && scienceScores.size() > 1) {
        double correlation = findPearsonCorrelation(mathScores, scienceScores);

        // Prepare the results to be written to the CSV file
        fstream file(outputFile, ios::out);
        file << "Attribute 1 (Math),Attribute 2 (Science),Pearson Correlation Coefficient\n";
        file << "Math,Science," << correlation << endl;

        cout << "Pearson Correlation Coefficient between Math and Science: " << correlation << endl;
        cout << "Results saved to: " << outputFile << endl;
    } else {
        cerr << "Error: Insufficient valid data to calculate correlation." << endl;
    }

    return 0;
}
