#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

// Function for Equal Width Binning
void equalWidthBinning(vector<int>& data, int binCount) {
    auto minMaxPair = std::minmax_element(data.begin(), data.end());
    auto minIt = minMaxPair.first;
    auto maxIt = minMaxPair.second;

    int minValue = *minIt;
    int maxValue = *maxIt;

    int binWidth = std::ceil((maxValue - minValue + 1) / static_cast<double>(binCount));

    cout << "Equal Width Bins:" << endl;
    for (int i = 0; i < binCount; i++) {
        int binStart = minValue + i * binWidth;
        int binEnd = binStart + binWidth - 1;

        cout << "Bin " << i + 1 << " (" << binStart << " - " << binEnd << "): ";
        for (int num : data) {
            if (num >= binStart && num <= binEnd) {
                cout << num << " ";
            }
        }
        cout << endl;
    }
}

// Function for Equal Frequency Binning
void equalFrequencyBinning(vector<int>& data, int binCount) {
    std::sort(data.begin(), data.end());  // Sort the data for equal frequency binning

    int n = data.size();
    int binSize = n / binCount;  // Calculate number of items per bin
    int remaining = n % binCount; // Items left after equal distribution

    cout << "Equal Frequency Bins:" << endl;
    int index = 0;
    for (int i = 0; i < binCount; i++) {
        int currentBinSize = binSize + (remaining > 0 ? 1 : 0);  // Add 1 if there are remaining items to distribute
        remaining--;

        cout << "Bin " << i + 1 << ": ";
        for (int j = 0; j < currentBinSize; j++) {
            cout << data[index++] << " ";
        }
        cout << endl;
    }
}

int main() {
    // Default data points
    vector<int> data = {15, 21, 23, 32, 33, 37, 42, 45, 47, 50, 55, 61, 64, 69, 75};  

    int binCount, choice;

    // Take the number of bins from the user
    cout << "Enter the number of bins: ";
    cin >> binCount;

    // Prompt user to choose binning method
    cout << "Choose Binning Method:\n1. Equal Width Binning\n2. Equal Frequency Binning\nEnter choice: ";
    cin >> choice;

    if (choice == 1) {
        equalWidthBinning(data, binCount); // Call equal width binning
    } else if (choice == 2) {
        equalFrequencyBinning(data, binCount); // Call equal frequency binning
    } else {
        cout << "Invalid choice!" << endl;
    }

    return 0;
}
