#include <bits/stdc++.h>
using namespace std;

int main()
{

    fstream file("ass2_zdataset2.csv", ios::in);

    if (!file.is_open())
    {
        cout << "Error in opening file";
        return 0;
    }

    string line, mark;
    vector<double> weight;

    int i = 0;
    while (getline(file, line))
    {

        if (i == 0)
        {
            i++;
            continue;
        }

        stringstream str(line);
        getline(str, mark, ',');
        double mk = stod(mark);
        weight.push_back(mk);
    }

    int n = weight.size();

    sort(weight.begin(), weight.end());

    file.close();

    double sum = 0;
    for (auto mk : weight)
    {
        sum += mk;
    }

    double mean = sum / n;

    double dev_sq = 0;
    for (auto wt : weight)
    {
        dev_sq += (wt - mean) * (wt - mean);
    }

    double std_dev = sqrt(dev_sq / n);

    ofstream fw2("zscore.csv", ios::out);

    if (!fw2.is_open())
    {
        cout << "Error in creating Z-score Normalized data file.";
        return -1;
    }

    fw2 << "Z-Score Normalized Weight " << endl;

    for (auto wt : weight)
    {
        double z_score = (wt - mean) / std_dev;

        fw2 <<z_score << endl;
    }

    fw2.close();
    return 0;
}