#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <iomanip>

using namespace std;

int main() {
    string inputFilePath = "ass5_region_product_quantity.csv"; 
    string outputFilePath = "output_region_product_quantity.csv"; 

    map<string, map<string, int>> companyProductMap;  // Company -> Product -> Quantity
    map<string, int> companyTotalMap;  // Company -> Total quantity of all products
    int totalTV = 0, totalMobile = 0, totalTablet = 0;
    map<string, int> totalProductMap;  // Total for each product

    // Open input file
    ifstream inputFile(inputFilePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Could not open input file!" << endl;
        return 1;
    }

    string line;
    bool isHeader = true;

    // Read input file
    while (getline(inputFile, line)) {
        if (isHeader) {
            isHeader = false;
            continue;
        }

        stringstream ss(line);
        string company, product, quantityStr;
        getline(ss, company, ',');
        getline(ss, product, ',');
        getline(ss, quantityStr, ',');

        int quantity = stoi(quantityStr);

        // Trim spaces from the product and company names
        company = company.substr(0, company.find_last_not_of(" \t\n\r") + 1);
        product = product.substr(0, product.find_last_not_of(" \t\n\r") + 1);

        companyProductMap[company][product] += quantity;
        companyTotalMap[company] += quantity;

        totalProductMap[product] += quantity;

        // Track total quantities for each product
        if (product == "TV") {
            totalTV += quantity;
        } else if (product == "Mobile") {
            totalMobile += quantity;
        } else if (product == "Tablet") {
            totalTablet += quantity;
        }
    }

    inputFile.close();

    // Open output file
    ofstream outputFile(outputFilePath);
    if (!outputFile.is_open()) {
        cerr << "Error: Could not open output file!" << endl;
        return 1;
    }

    // Write header to output file
    outputFile << "Company,TV Count,TV (TWeight %),TV (DWeight %),Mobile Count,Mobile (TWeight %),Mobile (DWeight %),Tablet Count,Tablet (TWeight %),Tablet (DWeight %),Total Count" << endl;

    // Process each company
    for (const auto& company : companyProductMap) {
        const string& companyName = company.first;
        const auto& productMap = company.second;

        // Use count to check if the product exists before accessing it
        int tvCount = (productMap.count("TV") > 0) ? productMap.at("TV") : 0;
        int mobileCount = (productMap.count("Mobile") > 0) ? productMap.at("Mobile") : 0;
        int tabletCount = (productMap.count("Tablet") > 0) ? productMap.at("Tablet") : 0;

        int totalCount = companyTotalMap[companyName];

        double tvTWeight = totalTV > 0 ? (static_cast<double>(tvCount) / totalTV) * 100 : 0;
        double mobileTWeight = totalMobile > 0 ? (static_cast<double>(mobileCount) / totalMobile) * 100 : 0;
        double tabletTWeight = totalTablet > 0 ? (static_cast<double>(tabletCount) / totalTablet) * 100 : 0;

        double tvDWeight = totalCount > 0 ? (static_cast<double>(tvCount) / totalCount) * 100 : 0;
        double mobileDWeight = totalCount > 0 ? (static_cast<double>(mobileCount) / totalCount) * 100 : 0;
        double tabletDWeight = totalCount > 0 ? (static_cast<double>(tabletCount) / totalCount) * 100 : 0;

        outputFile << companyName << ","
                   << tvCount << "," << fixed << setprecision(2) << tvTWeight << "%," << tvDWeight << "%,"
                   << mobileCount << "," << fixed << setprecision(2) << mobileTWeight << "%," << mobileDWeight << "%,"
                   << tabletCount << "," << fixed << setprecision(2) << tabletTWeight << "%," << tabletDWeight << "%,"
                   << totalCount << endl;
    }

    // Write total row
    outputFile << "Total,"
               << totalProductMap["TV"] << ",100%,100%,"
               << totalProductMap["Mobile"] << ",100%,100%,"
               << totalProductMap["Tablet"] << ",100%,100%,"
               << totalProductMap["TV"] + totalProductMap["Mobile"] + totalProductMap["Tablet"] << endl;

    outputFile.close();

    cout << "Output written to: " << outputFilePath << endl;

    return 0;
}
