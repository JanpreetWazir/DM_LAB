    #include <iostream>
    #include <fstream>
    #include <sstream>
    #include <string>
    #include <map>
    #include <cmath>
    #include <iomanip>
    using namespace std;

    // Function to calculate entropy based on counts of "Yes" and "No"
    double calculateEntropy(int yesCount, int total) {
        if (total == 0) return 0;
        double pYes = static_cast<double>(yesCount) / total;
        double pNo = 1 - pYes;
        return -pYes * log2(pYes) - pNo * log2(pNo);
    }

    // Function to calculate log base 2 of a number
    double log2(double value) {
        if (value == 0) return 0;
        return log(value) / log(2);
    }

    int main() {
        // Open the CSV file
        fstream file("ass4_cricket_data.csv", ios::in);
        if (!file.is_open()) {
            cout << "Error in opening the file." << endl;
            return 1;
        }

        string line;
        // Skip the header line
        getline(file, line);

        // Map to store the counts of "Yes" and "No" for each attribute-value pair
        map<string, map<string, pair<int, int>>> attributeMap;

        // Read each line of the CSV file
        while (getline(file, line)) {
            stringstream ss(line);

            string outlook, temperature, humidity, wind, playing;
            
            // Read each field of the line
            getline(ss, outlook, ',');
            getline(ss, temperature, ',');
            getline(ss, humidity, ',');
            getline(ss, wind, ',');
            getline(ss, playing, ',');

            // Update the map for each attribute-value pair
            if (playing == "Yes") {
                attributeMap["Outlook"][outlook].first++;       // Increment "Yes" count for Outlook
                attributeMap["Temperature"][temperature].first++; // Increment "Yes" count for Temperature
                attributeMap["Humidity"][humidity].first++;     // Increment "Yes" count for Humidity
                attributeMap["Wind"][wind].first++;             // Increment "Yes" count for Wind
            } else {
                attributeMap["Outlook"][outlook].second++;      // Increment "No" count for Outlook
                attributeMap["Temperature"][temperature].second++; // Increment "No" count for Temperature
                attributeMap["Humidity"][humidity].second++;    // Increment "No" count for Humidity
                attributeMap["Wind"][wind].second++;            // Increment "No" count for Wind
            }
        }

        file.close();

        // Calculate total "Yes" and "No" counts
        int totalYes = 0, totalNo = 0;
        for (const auto& attribute : attributeMap) {
            for (const auto& value : attribute.second) {
                totalYes += value.second.first;
                totalNo += value.second.second;
            }
        }

        // Calculate entropy of the parent node (overall entropy for "Yes" and "No")
        int total = totalYes + totalNo;
        double parentEntropy = calculateEntropy(totalYes, total);

        cout << "Parent Entropy: " << fixed << setprecision(4) << parentEntropy << endl;

        // Calculate information gain for each attribute
        for (const auto& attribute : attributeMap) {
            string attributeName = attribute.first;
            double weightedEntropy = 0;

            cout << "\nAttribute: " << attributeName << endl;
            cout << "| Value      | Yes Count | No Count | Total | Entropy |\n";
            cout << "-----------------------------------------------------\n";

            for (const auto& value : attribute.second) {
                const string& valueName = value.first;
                int yesCount = value.second.first;
                int noCount = value.second.second;
                int childTotal = yesCount + noCount;

                // Calculate entropy for each attribute-value pair
                double childNodeEntropy = calculateEntropy(yesCount, childTotal);
                weightedEntropy += (static_cast<double>(childTotal) / total) * childNodeEntropy;

                cout << "| " << setw(10) << left << valueName 
                    << " | " << setw(9) << yesCount 
                    << " | " << setw(8) << noCount 
                    << " | " << setw(5) << childTotal 
                    << " | " << setw(8) << fixed << setprecision(4) << childNodeEntropy << " |\n";
            }

            cout << "-----------------------------------------------------\n";
            cout << "Total Weighted Entropy for " << attributeName << ": " << fixed << setprecision(4) << weightedEntropy << endl;
            cout << "Information Gain for " << attributeName << ": " << fixed << setprecision(4) << parentEntropy - weightedEntropy << endl;
        }

    return 0;
    }