#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

vector<set<string>> transactions;

map<set<string>, int> getItemsetCounts(int setSize);
void printFrequentItemsets(map<set<string>, int>& itemsetCount, int totalTransactions, double minSupportThreshold);
set<set<string>> getCombinations(const set<string>& transaction, int setSize);
void generateCombinations(set<set<string>>& combinations, set<string>& currentSet, const vector<string>& items, int index, int setSize);
map<set<string>, int> generateNextItemsets(const set<set<string>>& previousItemsets, int setSize);
double getSupport(const set<string>& itemset, const map<set<string>, int>& itemsetCount, int totalTransactions);
void generateAndPrintAssociationRules(const set<string>& itemset, const map<set<string>, int>& itemsetCount, int totalTransactions, double minSupportThreshold);

int main() {
    string csvFile = "ass7_freq_item_set.csv"; 
    string line;
    char csvSplitBy = ',';
    double minSupportThreshold = 0.3;

    ifstream file(csvFile);

    if (!file.is_open()) {
        cerr << "Unable to open file" << endl;
        return 1;
    }

    // Read transactions from file
    getline(file, line);  // Skip header
    while (getline(file, line)) {
        stringstream ss(line);
        string item;
        set<string> items;
        int index = 0;
        while (getline(ss, item, csvSplitBy)) {
            if (index > 0 && !item.empty()) { 
                items.insert(item);
            }
            index++;
        }
        transactions.push_back(items);
    }
    file.close();

    int k = 1;
    map<set<string>, int> currentItemsetCount = getItemsetCounts(1);
    map<set<string>, int> frequentItemsets;

    while (!currentItemsetCount.empty()) {
        cout << "\n" << k << "-itemsets with support >= " << minSupportThreshold << ":\n";
        printFrequentItemsets(currentItemsetCount, transactions.size(), minSupportThreshold);
        frequentItemsets.insert(currentItemsetCount.begin(), currentItemsetCount.end());

        // Generate association rules for current itemsets
        for (const auto& itemset : currentItemsetCount) {
            generateAndPrintAssociationRules(itemset.first, frequentItemsets, transactions.size(), minSupportThreshold);
        }

        set<set<string>> previousItemsets;
        for (const auto& item : frequentItemsets) {
            previousItemsets.insert(item.first);
        }
        currentItemsetCount = generateNextItemsets(previousItemsets, k + 1);
        k++;
    }

    return 0;
}

map<set<string>, int> getItemsetCounts(int setSize) {
    map<set<string>, int> itemsetCount;

    for (const auto& transaction : transactions) {
        if (transaction.size() >= setSize) {
            set<set<string>> combinations = getCombinations(transaction, setSize);
            for (const auto& combination : combinations) {
                itemsetCount[combination]++;
            }
        }
    }

    return itemsetCount;
}

void printFrequentItemsets(map<set<string>, int>& itemsetCount, int totalTransactions, double minSupportThreshold) {
    for (const auto& entry : itemsetCount) {
        double support = static_cast<double>(entry.second) / totalTransactions;
        if (support >= minSupportThreshold) {
            cout << "Item set: { ";
            for (const string& item : entry.first) {
                cout << item << " ";
            }
            cout << "} | Support: " << support << " | Count: " << entry.second << endl;
        }
    }
}

set<set<string>> getCombinations(const set<string>& transaction, int setSize) {
    set<set<string>> combinations;
    vector<string> transactionList(transaction.begin(), transaction.end());
    set<string> currentSet;
    generateCombinations(combinations, currentSet, transactionList, 0, setSize);
    return combinations;
}

void generateCombinations(set<set<string>>& combinations, set<string>& currentSet, const vector<string>& items, int index, int setSize) {
    if (currentSet.size() == setSize) {
        combinations.insert(currentSet);
        return;
    }

    for (int i = index; i < items.size(); i++) {
        currentSet.insert(items[i]);
        generateCombinations(combinations, currentSet, items, i + 1, setSize);
        currentSet.erase(items[i]);
    }
}

map<set<string>, int> generateNextItemsets(const set<set<string>>& previousItemsets, int setSize) {
    map<set<string>, int> nextItemsetCount;

    for (const auto& transaction : transactions) {
        if (transaction.size() >= setSize) {
            set<set<string>> combinations = getCombinations(transaction, setSize);
            for (const auto& combination : combinations) {
                nextItemsetCount[combination]++;
            }
        }
    }

    return nextItemsetCount;
}

// Function to calculate the support for an itemset
double getSupport(const set<string>& itemset, const map<set<string>, int>& itemsetCount, int totalTransactions) {
    if (itemsetCount.find(itemset) != itemsetCount.end()) {
        return static_cast<double>(itemsetCount.at(itemset)) / totalTransactions;
    }
    return 0.0;
}

// Function to generate and print association rules and their confidence
void generateAndPrintAssociationRules(const set<string>& itemset, const map<set<string>, int>& itemsetCount, int totalTransactions, double minSupportThreshold) {
    // Generate all possible subsets of the itemset
    vector<string> itemsetVector(itemset.begin(), itemset.end());
    int n = itemsetVector.size();

    for (int i = 1; i < (1 << n); i++) {  // Loop over all non-empty subsets
        set<string> leftSide;
        for (int j = 0; j < n; j++) {
            if (i & (1 << j)) {
                leftSide.insert(itemsetVector[j]);
            }
        }

        // Right side of the rule is itemset - leftSide
        set<string> rightSide = itemset;
        for (const string& item : leftSide) {
            rightSide.erase(item);
        }

        if (!rightSide.empty()) {
            // Calculate support for left, right and the rule (left -> right)
            double supportLeft = getSupport(leftSide, itemsetCount, totalTransactions);
            double supportRight = getSupport(rightSide, itemsetCount, totalTransactions);
            double supportBoth = getSupport(itemset, itemsetCount, totalTransactions);

            // Calculate confidence
            double confidence = supportBoth / supportLeft;

            if (supportLeft >= minSupportThreshold && supportRight >= minSupportThreshold) {
                cout << "Rule: { ";
                for (const string& item : leftSide) {
                    cout << item << " ";
                }
                cout << "} -> { ";
                for (const string& item : rightSide) {
                    cout << item << " ";
                }
                cout << "} | Support: " << supportBoth << " | Confidence: " << confidence << endl;
            }
        }
    }
}
