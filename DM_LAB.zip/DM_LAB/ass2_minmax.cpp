#include <fstream>
#include<bits/stdc++.h>

using namespace std;

int main() {
    fstream inputFile("ass2_dataset.csv", ios::in);
    if (!inputFile.is_open()) {
        cout << "Error in opening file";
        return 0;
    }

    string line, w;
    vector<double> weight;
    int i = 0;

    while (getline(inputFile, line)) {
        if (i == 0) {
            i++;
            continue;
        }
        stringstream str(line);
        getline(str, w, ',');
        weight.push_back(stod(w));
    }
    inputFile.close();

    // Sorting and getting min/max values
    sort(weight.begin(), weight.end());
    double old_min = weight.front(), old_max = weight.back();
    double new_min, new_max;

    cout << "Enter New Minimum: ";
    cin >> new_min;
    cout << "Enter New Maximum: ";
    cin >> new_max;

    fstream fout("min_max_output.csv", ios::out);
    if (!fout.is_open()) {
        cout << "Error in creating output file";
        return -1;
    }

    fout << "Values After Min-max Normalization" << endl;
    for (double x : weight) {
        double normalized_weight = (((x - old_min) / (old_max - old_min)) * (new_max - new_min)) + new_min;
        fout << normalized_weight << endl;
    }
    fout.close();

    return 1;
}
